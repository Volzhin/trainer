repo: Volzhin/trainer
branch: main

## Last sync
date: 2026-08-02T00:00:00Z
note: GitHub-приложение не подключено — репозиторий прочитан как публичная страница (README + index.html). Токены выведены из theme-color #0b0d10 и описания UI, а не из реального CSS. При подключении GitHub сверить с src/styles.css и src/components/*.

### Updated in this project
- Создана дизайн-система Trainer DS v0.1 (тёмная + светлая тема)
- Токены выгружены в tokens/tokens.css, tokens/tailwind.config.js, tokens/tokens.json

## Screen map
| Экран / раздел DS | Источник в репозитории |
| --- | --- |
| Навигация, таб-бар | src/components/TabBar |
| Таймер отдыха, плашка тренировки | src/components/RestTimer, src/store/app.tsx |
| Шторки, выбор упражнения | src/components/Sheet, ExercisePicker |
| Графики и данные | src/components/LineChart, src/lib/calc.ts |
| Экран «Тренировка» | src/pages/LiveSession.tsx |
| Экран «Главная» | src/pages/Home.tsx |
| Экран «Прогресс» | src/pages/Progress.tsx |
