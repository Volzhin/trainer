// Trainer DS — tailwind.config.js (theme.extend)
// Цвета ссылаются на CSS-переменные из tokens/tokens.css, поэтому
// светлая тема включается через <html data-theme="light"> без пересборки.
module.exports = {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        bg: 'var(--bg)',
        'bg-elev': 'var(--bg-elev)',
        surface: 'var(--surface)',
        'surface-2': 'var(--surface-2)',
        border: 'var(--border)',
        'border-strong': 'var(--border-strong)',
        text: { DEFAULT: 'var(--text)', 2: 'var(--text-2)', 3: 'var(--text-3)' },
        accent: { DEFAULT: 'var(--accent)', press: 'var(--accent-press)', soft: 'var(--accent-soft)', on: 'var(--on-accent)' },
        ok: { DEFAULT: 'var(--ok)', soft: 'var(--ok-soft)' },
        warn: { DEFAULT: 'var(--warn)', soft: 'var(--warn-soft)' },
        danger: { DEFAULT: 'var(--danger)', soft: 'var(--danger-soft)' },
        info: { DEFAULT: 'var(--info)', soft: 'var(--info-soft)' },
      },
      borderRadius: { sm: 'var(--r-sm)', md: 'var(--r-md)', lg: 'var(--r-lg)', xl: 'var(--r-xl)', '2xl': 'var(--r-2xl)', full: 'var(--r-full)' },
      spacing: { 1: '4px', 2: '8px', 3: '12px', 4: '16px', 5: '20px', 6: '24px', 8: '32px', 10: '40px', 14: '56px', tap: '48px' },
      boxShadow: { 1: 'var(--shadow-1)', 2: 'var(--shadow-2)', sheet: 'var(--shadow-sheet)' },
      fontFamily: { ui: ['Manrope', 'system-ui', 'sans-serif'], num: ['JetBrains Mono', 'ui-monospace', 'monospace'] },
      fontSize: {
        display: ['44px', { lineHeight: '1.05', letterSpacing: '-.03em', fontWeight: '800' }],
        h1: ['28px', { lineHeight: '1.15', letterSpacing: '-.02em', fontWeight: '800' }],
        h2: ['20px', { lineHeight: '1.25', fontWeight: '700' }],
        body: ['15px', { lineHeight: '1.55' }],
        label: ['13px', { lineHeight: '1.4', fontWeight: '600' }],
        overline: ['11px', { lineHeight: '1', letterSpacing: '.14em', fontWeight: '800' }],
      },
      transitionTimingFunction: { ds: 'cubic-bezier(.2,.8,.2,1)' },
      transitionDuration: { fast: '120ms', ds: '200ms', slow: '340ms' },
      zIndex: { sticky: '10', tabbar: '20', sheet: '30', toast: '40', rest: '50' },
    },
  },
  plugins: [],
};
